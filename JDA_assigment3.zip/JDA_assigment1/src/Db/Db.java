package Db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Db {
    public Connection connect() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/workersdb", "root", "");
        return conn;
    }

    public void insertWorker(Worker worker) throws SQLException {
        Connection conn = connect();
        Statement st = conn.createStatement();
        String query =
                "insert into workerstable values (null, '" + worker.name + "','" + worker.ageNumber + "','" +
                        worker.adress + "','" + worker.sallary + "')";

        st.execute(query);
        conn.close();
    }

    public void deleteWorker(int id) throws SQLException {
        Connection conn = connect();
        Statement st = conn.createStatement();
        String query = "delete from workerstable where id = " + id;
        st.execute(query);
        st.close();
        conn.close();
    }

    public void updateWorker(Worker worker) throws SQLException {

        Connection conn = connect();
        PreparedStatement st = conn.prepareStatement("update workerstable set name= ?,ageNumber= ?,adress= ?,salary= ?, where id = ?");

        st.setString(1, worker.name);
        st.setInt(2, worker.ageNumber);
        st.setString(3, worker.adress);
        st.setInt(4, worker.sallary);
        st.setInt(5, worker.id);


        st.execute();
        st.close();
        conn.close();
    }

    public List<Worker> getAllWorkers() throws SQLException {
        List res = new ArrayList();

        Connection conn = connect();
        Statement st = conn.createStatement();
        String query = "select * from workerstable";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Worker worker = new Worker();
            worker.id = rs.getInt("id");
            worker.name = rs.getString("name");
            worker.ageNumber = Integer.parseInt(rs.getString("ageNumber"));
            worker.adress = rs.getString("adress");
            worker.sallary = Integer.parseInt(rs.getString("sallary"));

            res.add(worker);


        }
        return res;
    }

    public Worker getWorker(int id) throws SQLException {
        Worker worker = null;

        Connection conn = connect();

        PreparedStatement st = conn.prepareStatement("select * from workerstable where id = ?");
        st.setInt(1, id);

        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            worker = new Worker();
            worker.id = rs.getInt("id");
            worker.name = rs.getString("name");
            worker.ageNumber = Integer.parseInt(rs.getString("ageNumber"));
            worker.adress = rs.getString("adress");
            worker.sallary = Integer.parseInt(rs.getString("sallary"));
        }

        rs.close();
        st.close();
        conn.close();

        return worker;
    }


}
