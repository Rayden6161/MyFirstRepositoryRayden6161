package Db;

public class Worker {
    public int id;
    public String name;
    public int ageNumber;

    public String adress;
    public int sallary;

    public Worker(int id, String name, int ageNumber, String adress, int sallary) {
        this.id =id;
        this.name= name;
        this.ageNumber = ageNumber;
        this.adress = adress;
        this.sallary = sallary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAgeNumber() {
        return ageNumber;
    }

    public void setAgeNumber(int ageNumber) {
        this.ageNumber = ageNumber;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public int getSallary() {
        return sallary;
    }

    public void setSallary(int sallary) {
        this.sallary = sallary;
    }

    public Worker() {

    }

    @Override
    public String toString() {
        return id + "\t" + name + "\t" + ageNumber +"\t" + adress + "\t" +sallary;

}
}
