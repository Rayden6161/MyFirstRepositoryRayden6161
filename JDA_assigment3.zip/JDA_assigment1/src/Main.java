
import Db.Db;
import Db.Worker;

import java.sql.*;

public class Main {
    public static void main(String[] args) throws SQLException {
      try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/workersDb", "root",
                "")){

          Worker worker  = new Worker();
          Db db = new Db();
          worker.id=1;
          worker.name = "Zeljko";
          worker.ageNumber =33;
          worker.adress="Lovcenac";
          worker.sallary=444;
         


          // db.insertWorker(worker);

          // System.out.println(db.getAllWorkers());


          // db.deleteWorker(2);


          // db.getWorker(1)
          //System.out.println(db.getWorker(1));

          // db.updateWorker(worker);







      }catch (SQLException ex){
          System.out.println("Error in database" + ex.getMessage());
      }




    }
}