package org.example.model;

public enum Duration {
    ONEYEAR,
    TWOYEARS
}
