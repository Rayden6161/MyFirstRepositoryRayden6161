package org.example.model;

public enum Bandwitch {ONE,
    FIVE,
    TEN,
    HUNDRED,
    FLAT
}
