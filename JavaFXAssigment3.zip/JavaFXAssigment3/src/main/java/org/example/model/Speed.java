package org.example.model;

public enum Speed {
	TWO,
	FIVE,
	TEN,
	TWENTY,
	FIFTY,
	HUNDRED
}
